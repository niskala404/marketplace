<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
   public function up(): void
{
    Schema::table('products', function (Blueprint $table) {
        if (!Schema::hasColumn('products', 'sold_count')) {
            $table->unsignedInteger('sold_count')->default(0)->after('stock'); // sesuaikan after()
            $table->index('sold_count');
        }
    });
}

public function down(): void
{
    Schema::table('products', function (Blueprint $table) {
        if (Schema::hasColumn('products', 'sold_count')) {
            $table->dropIndex(['sold_count']);
            $table->dropColumn('sold_count');
        }
    });
}
};